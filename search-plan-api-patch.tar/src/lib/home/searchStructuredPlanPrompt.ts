import type {
  SearchPlanIncrementFocus,
  SearchPlanRequest,
  SearchStructuredPlan,
} from '@/types/domain/searchStructuredPlan';

/** 写死在接口层的 System Prompt：只出 JSON，禁止散文流水账 */
export const SEARCH_STRUCTURED_PLAN_SYSTEM_PROMPT = `你是专业旅游行程生成器，严格遵守以下规则：
1.只输出纯净JSON，不要\`\`\`json标记，不要任何解释、开场白、抒情段落，禁止流水账散文。
2.输出结构必须严格匹配下面schema，字段一个不能缺失。
3.预算不为null时，全程消费不能超出给定人均预算；为null则做常规合理消费。
4.每天行程节奏松弛，不堆砌景点；包含真实地铁/公交/打车交通、真实门店名称、菜品、参考人均。
5.景点附带简短介绍；增加出行贴士；住宿统一固定片区，全程不换住宿地点。
6.不要虚构不存在的景点餐馆。

输出JSON结构：
{
  "baseInfo":{
    "startCity":"",
    "targetCity":"",
    "days":1,
    "peopleType":"",
    "budget":null,
    "theme":null
  },
  "budgetList":[
    {"item":"往返大交通","perPerson":0,"tip":"省钱说明"},
    {"item":"市内交通","perPerson":0,"tip":""},
    {"item":"餐饮","perPerson":0,"tip":""},
    {"item":"门票","perPerson":0,"tip":""},
    {"item":"住宿","perPerson":0,"tip":""},
    {"item":"机动备用金","perPerson":0,"tip":""},
    {"item":"合计","perPerson":0,"tip":""}
  ],
  "dayList":[
    {
      "day":1,
      "title":"第X天标题",
      "traffic":[{"desc":"交通描述"}],
      "spots":[{"name":"景点名","intro":"简短介绍"}],
      "foods":[{"shop":"餐馆名","dish":"招牌菜","perCost":0}],
      "tips":"当日小提示",
      "hotelArea":"住宿片区"
    }
  ],
  "globalTips":["全局出行贴士1","贴士2"]
}`;

export function buildSearchStructuredPlanUserPrompt(params: SearchPlanRequest): string {
  return `请根据以下已确认参数生成行程JSON：\n${JSON.stringify(params)}`;
}

const INCREMENT_FOCUS_RULE: Record<SearchPlanIncrementFocus, string> = {
  spots:
    '只加长 dayList[].spots[].intro（简短介绍写具体一点），禁止增删景点、禁止改 name、禁止改 foods/traffic/tips/hotelArea。',
  foods:
    '只丰富或少量追加 dayList[].foods（shop/dish/perCost），禁止改景点顺序与 name、禁止改 traffic、禁止改住宿与预算数字。',
  traffic:
    '只补充 dayList[].traffic[].desc 的地铁/公交换乘细节，禁止改景点、美食、住宿、预算数字与天数。',
};

export function buildSearchPlanIncrementSystemPrompt(focus: SearchPlanIncrementFocus): string {
  return `你是行程局部扩写器，严格遵守：
1.只输出纯净JSON，不要\`\`\`json标记，不要解释。
2.输出必须与输入同一schema，dayList长度、每天day/title/hotelArea必须原样保留。
3.禁止修改 baseInfo.days、路线顺序、住宿片区、budgetList 里任何数字。
4.${INCREMENT_FOCUS_RULE[focus]}
5.不要虚构不存在的景点餐馆。`;
}

export function buildSearchPlanIncrementUserPrompt(
  focus: SearchPlanIncrementFocus,
  plan: SearchStructuredPlan,
): string {
  return `对下面完整行程做「${focus}」局部扩充，其他字段保持原样：\n${JSON.stringify(plan)}`;
}
